create function logwork() returns trigger
    language plpgsql
as
$$
begin
    insert into works_on_log  (essn,date) values (new.essn,current_date);
    return null;
End;
$$;

alter function logwork() owner to postgres;

